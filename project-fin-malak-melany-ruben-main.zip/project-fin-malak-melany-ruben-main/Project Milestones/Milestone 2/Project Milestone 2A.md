![Relational Schema](<Project Milestone 2A.png>)

**Explanation:**
- Individuals:
    - Represents people in the system.
    - Attributes: ID, Address, Name, Phone #, Resources Provided, Individual Needs (Optional).
    - Relationship: Can provide or request resources.

- Resources:
    - Represents available resources.
    - Attributes: Resource ID, Mentor, Provider, Type, Location.
    - Relationship: Provided by Individuals or Volunteers, accessed by those in need.

- Volunteers:
    - Represents volunteers offering services or providing resources.
    - Attributes: ID, Name, Address, Email, Phone Number, Service Provided, Resource Provided.
    - Relationship: Can provide services and resources.

- Services:
    - Represents various services available.
    - Attributes: Service ID, Service Type, Availability.
    - Relationship: Offered by Volunteers or organizations.

- Needs:
    - Represents individuals' or communities' needs.
    - Attributes: Need Request ID, Type, Priority.
    - Relationship: Connected to Individuals or Volunteers requesting help.

- Relationships:
    - Individuals and Resources: Individuals can provide or need resources.
    - Resources and Volunteers: Volunteers can provide or request resources.
    - Volunteers and Services: Volunteers can offer specific services.
    - Needs and Services: Needs are matched with available services.

**Discussion:**
- Some advantages from our P1 model are that the model captures essential components of the mutual aid system, including Individuals, Volunteers, Resources, Services, and Needs, and that the defined relationships allow for tracking of resource and services distribution. The model also makes sure that resources and services are properly linked to providers and requesters. The distinction between Individuals and Volunteers also helps clarify different roles in the system. The model also accommodates different types of needs, services, and resources without requiring major structural changes.
- A potential improvement is that both Individuals and Volunteers have similar attributes (e.g., Name, Address, Phone #, Resources Provided). Consolidating these into a single entity might simplify the model. We could also have a "Role" attribute within Individuals to indicate whether they are requesters, providers, or both.