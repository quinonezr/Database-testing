CREATE TABLE "Needs" (
    "id" INTEGER PRIMARY KEY NOT NULL,
    "type" NVARCHAR(20) NOT NULL,
    "priority" INTEGER NOT NULL,
    "requester_id" INTEGER NOT NULL,
    FOREIGN KEY ("requester_id") REFERENCES "Users"("id")
);

CREATE TABLE "Resources" (
    "id" INTEGER PRIMARY KEY NOT NULL,
    "description" NVARCHAR(250) NOT NULL,
    "provider_id" INTEGER NOT NULL,
    "type" NVARCHAR(20) NOT NULL,
    "street_address" NVARCHAR(100) NOT NULL,
    "city" NVARCHAR(20) NOT NULL,
    "state" NVARCHAR(2) NOT NULL,
    "zip_code" NVARCHAR(10) NOT NULL,
    FOREIGN KEY ("provider_id") REFERENCES "Users"("id")
);

CREATE TABLE "Services" (
    "id" INTEGER PRIMARY KEY NOT NULL,
    "type" NVARCHAR(20) NOT NULL,
    "availability" INTEGER NOT NULL,
    "provider_id" INTEGER NOT NULL,
    FOREIGN KEY ("provider_id") REFERENCES "Users"("id")
);

CREATE TABLE "Individuals" (
    "id" INTEGER PRIMARY KEY NOT NULL,
    "first_name" NVARCHAR(20) NOT NULL,
    "last_name" NVARCHAR(20) NOT NULL,
    "street_address" NVARCHAR(100),
    "city" NVARCHAR(20),
    "state" NVARCHAR(2) NOT NULL,
    "zip_code" NVARCHAR(10) NOT NULL,
    "volunteer" BOOLEAN NOT NULL,
    "admin" BOOLEAN
);

INSERT INTO "Individuals" ("id", "first_name", "last_name", "street_address", "city", "state", "zip_code", "volunteer") 
VALUES 
(1, 'John', 'Doe', '123 Main St', 'Lexington', 'KY', '40508', TRUE),
(2, 'Jane', 'Smith', '456 Oak Ave', 'Louisville', 'KY', '40202', TRUE),
(3, 'Emily', 'Johnson', '789 Pine Rd', 'Frankfort', 'KY', '40601', FALSE);

INSERT INTO "Services" ("id", "type", "availability", "provider_id") 
VALUES 
(1, 'Food Assistance', 10, 1),
(2, 'Legal Aid', 5, 2),
(3, 'Job Training', 7, 3);

INSERT INTO "Resources" ("id", "description", "provider_id", "type", "street_address", "city", "state", "zip_code") 
VALUES 
(3, 'Flour', 6, 'Food', '301 Willow Street', 'Berea', 'Kentucky', '40403'),
(4, 'Wooden Planks', 7, 'Building Supplies', '201 S Negley St.', 'Pittsburgh', 'Pennsylvania', '15232'),
(5, 'Tire', 8, 'Vehicle', '101 Chestnut St', 'Berea', 'Kentucky', '40403');


INSERT INTO "Needs" ("id", "type", "priority", "requester_id") 
VALUES 
(3, 'Diapers', 6, 5),
(7, 'Cooking supplies', 7, 2),
(6, 'Newborn clothes', 2, 4);