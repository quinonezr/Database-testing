- **Data Sources:** <br>
    - Mock data <br>
    - Possibility of existing member tracker with context menu features. <br>
    - Discussed tracking donations (incoming and outgoing inventory). <br>
    - Recognized the need to track individual needs accurately and efficiently <br>
    - [Airtable - KHJN Trans Health Resource Portal](https://airtable.com/app84XQZoLgcbm3Is/shrUfe8yX5dJEFqxy/tblEyUZWQVu4gPPcC/viwjrXhLl2cqxsGEh) <br>
    - [Resources Needed List](https://docs.google.com/spreadsheets/d/1AMnsrqaD1mESzi-PpXe9xVAvdhorUe18A9mGfeureSA/edit?gid=0#gid=0) <br>

- **Business Rules:** <br>
    1. Mutual Aid Work & Fast-Paced Data Needs
        - Recognized the need for a system that quickly adapts to changes in resource availability and community needs.
        - Discussed the importance of tracking donations (incoming and outgoing inventory).
        - Emphasized the necessity of linking services effectively to those in need.
        - Explored ways to track individual needs accurately and efficiently.
    2. Data Tracking & Types of Data Needed
        - Identifying information: Names and other relevant details.
        - Specific needs: Individual and disaster response requirements.
        - Mutual aid coordination: How to facilitate and exchange community-supported mutual aid.
        - Volunteer coordination: Tracking availability and matching volunteers accordingly.
    3. System Features & Functionality
        - Matching System:
        - Automated matching to link needs with available resources.
        - User-friendly interface to ensure accessibility.
        - Confidentiality & Permissions:
            - Public feature vs. internal feature for privacy protection.
            - Only admins have edit access to shared documents.
            - Individuals can edit/delete their own profiles.
        - Design & Community Engagement:
            - Avoid designs resembling previous forms used.
            - Engage the community in managing the document.
            - Consideration of a mutual aid card system (idea was lifted).
    4. Technical Aspects & Implementation
        - Use of mock data for initial testing.
        - Existing member tracker available with context menu features.
        - Ensuring secure and efficient data management.

- **Entity Names and Definitions:** <br>
    - Individuals: Includes names and other relevant details. <br>
    - Needs: Individual and disaster response requirements. <br>
    - Resources/Donations: Incoming and outgoing inventory. <br>
    - Volunteers: Availability tracked and matched accordingly. <br>
    - Services: Linked to those in need. <br> <br>

![KSEC E-R Diagram](<Project Milestone 1 - KSEC.png>)