- **Clarify: Who are your users?** <br> <br>
    1. Admin Users (Organization Representatives & Mutual Aid Coordinators) <br>
        - Goals: <br>
            - Manage and oversee the mutual aid system. <br>
            - Input requests on behalf of individuals who do not have access to the database or a device. <br>
            - Approve, modify, or remove requests and resource listings. <br>
            - Maintain the integrity of the data and ensure privacy/security protocols are followed. <br>
            - Facilitate connections between those offering and those needing resources. <br>
    2. General Users (Community Members Seeking or Providing Aid) <br>
        - Goals: <br>
            - Create and manage their own profile in the system. <br>
            - Specify whether they are offering or needing a resource. <br>
            - Search for available resources or post requests for needed items/services. <br>
            - Update or remove their requests/resources as their needs change. <br>
            - Connect with mutual aid opportunities in their local or national area. <br>
    3. Volunteers (Individuals Offering Services or Resources) <br>
        - Goals: <br>
            - Register their availability and the types of resources or services they can provide. <br>
            - Be matched with individuals or communities in need. <br>
            - Receive notifications or updates about new requests that match their offerings. <br>
    4. Proxy Users (Admins Inputting Data for Others) <br>
        - Goals: <br>
            - Assist individuals who do not have direct access to the application by entering requests on their behalf. <br>
            - Ensure accurate and up-to-date information for users who rely on external assistance. <br>
            - Maintain transparency in the system while protecting user privacy. <br> <br>
- **Understand the Application Users’ Needs** <br> <br>
    1. Admin Users (Organization Representatives & Mutual Aid Coordinators) <br>
        - (HIGH) How many active requests exist in a specific region? **READ, UPDATE** <br>
        - (HIGH) What resources are currently available, and where are they located? **READ, UPDATE, DELETE** <br>
        - (HIGH) Can I input a request on behalf of someone who does not have access? **CREATE** <br>
        - (HIGH) Which volunteers are available, and what services do they offer? **READ, UPDATE** <br>
        - (MEDIUM) How many requests have been fulfilled within the past month? **READ, UPDATE** <br>
        - (MEDIUM) Can I modify or remove an outdated request or resource listing? **UPDATE, DELETE** <br>
        - (LOW) How many new users have registered in the past week/month? **READ, UPDATE** <br>
    2. General Users (Community Members Seeking or Providing Aid) <br>
        - (HIGH) What resources are available in my area that match my needs? **READ** <br>
        - (HIGH) Can I submit a request for aid and update or delete it if needed? **CREATE, UPDATE, DELETE** <br>
        - (MEDIUM) Who is offering aid, and how can I contact them? **READ** <br>
        - (LOW) How many other people in my area have similar needs? **READ** <br>
    3. Volunteers (Individuals Offering Services or Resources) <br>
        - (HIGH) Who is currently in need of the services/resources I provide? **READ** <br>
        - (HIGH) Can I list or modify the aid I’m offering? **CREATE, DELETE, UPDATE** <br>
        - (MEDIUM) What is the priority level of the requests near me? **READ** <br>
        - (LOW) What percentage of my past offers have been utilized? **READ** <br>
    4. Proxy Users (Admins Inputting Data for Others) <br>
        - (HIGH) Can I enter and track requests for individuals without direct access? **CREATE, UPDATE** <br>
        - (HIGH) How can I ensure the confidentiality of user information while managing requests? **READ, UPDATE** <br>
        - (MEDIUM) What are the most urgent needs in the database that require immediate attention? **READ, UPDATE** <br>
        - (LOW) How frequently do users without access require proxy assistance? **READ, UPDATE** <br> <br>
- **Create Data Flow Diagram** <br>
    - ![Admin Matching](Adminmatching.PNG) <br>
    - ![Personal Flow](PersonalFlow.PNG)
    - ![Request Added](Requestadded.PNG)
    - ![Resource Addition](Resourceaddition.PNG)
    - ![Search Resources](SearchResources.PNG)
    - ![Search Services](SearchServices.PNG)
    - ![Service Addition](Serviceaddition.PNG)
- **Sketch the User Interface**
    - ![User Interace Sketch 1](<Project Milestone 3 UI-1.jpeg>)
    - ![User Interace Sketch 2](<Project Milestone 3 UI-2.jpeg>)
    - ![User Interace Sketch 3](<Project Milestone 3 UI-3.jpeg>)
    - ![User Interace Sketch 4](<Project Milestone 3 UI-4.jpeg>)
