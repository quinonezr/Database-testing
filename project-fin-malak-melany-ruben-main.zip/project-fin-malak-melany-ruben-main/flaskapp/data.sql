-- https://www.programiz.com/sql/insert-into

-- Add SQL inserts here

INSERT INTO "users" ("first_name", "last_name", "street_address", "city", "state", "zip_code","username","password") 
VALUES 
('John', 'Doe', '123 Main St', 'Lexington', 'KY', '40508','user1','password1'),
('Jane', 'Smith', '456 Oak Ave', 'Louisville', 'KY', '40202','user2', 'password2'),
('Emily', 'Johnson', '789 Pine Rd', 'Frankfort', 'KY', '40601','user3','password3');

INSERT INTO "services" ("id", "type", "availability", "provider_id") 
VALUES 
(1, 'Food Assistance', 10, 1),
(2, 'Legal Aid', 5, 2),
(3, 'Job Training', 7, 3);

INSERT INTO "resources" ("id", "description", "provider_id", "type", "street_address", "city", "state", "zip_code") 
VALUES 
(3, 'Flour', 1, 'Food', '301 Willow Street', 'Berea', 'KY', '40403'),
(4, 'Wooden Planks', 2, 'Building Supplies', '201 S Negley St.', 'Pittsburgh', 'PA', '15232'),
(5, 'Tire', 3, 'Vehicle', '101 Chestnut St', 'Berea', 'KY', '40403');


INSERT INTO "needs" ("id", "type", "priority", "requester_id","contact","description") 
VALUES 
(3, 'item', 'Medium', 1, '2708852218','I need diapers'),
(7, 'food', 'Low', 2, 'basicemail@gmail.com','I am in need of cooking supplies'),
(6, 'item', 'Medium',  3, '885-930-4259','I need some clothes for my newborn');
