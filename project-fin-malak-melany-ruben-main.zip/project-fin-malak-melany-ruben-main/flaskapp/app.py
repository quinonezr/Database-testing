from flask import Flask, render_template, request, redirect, url_for, session
from models import db, Users, Needs, Resources, Services
import bcrypt

app = Flask(__name__)
app.secret_key = 'supersecretkey'  

@app.before_request
def before_request():
    if db.is_closed():
        db.connect()
        


@app.teardown_request
def teardown_request(exception):
    if not db.is_closed():
        db.close()

# --- HOME PAGE ---
@app.route('/')
def home():
    if ('loggedin' not in session):
        session['user_id'] = None
        session['loggedin'] = False
    return render_template('home.html')
    

# --- PROFILE PAGE ---
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if session['loggedin'] == True:
        profile = Users.select().where(Users.id == session['user_id'])
        requests = Needs.select().where(Needs.requester == session['user_id'])
        resources = Resources.select().where(Resources.provider_id == session['user_id'])
    else:
        profile = None
        requests = None
        resources = None
    return render_template('profile.html', profile=profile,requests=requests,resources=resources)

# --- REQUESTS PAGE ---
@app.route('/requests', methods=['GET', 'POST'])
def requests_page():
    if request.method == 'POST':
        user = Users.select().where(Users.id ==(session['user_id'])).get()  
        Needs.create(
            type=request.form['type'],
            priority=request.form['priority'],
            contact=request.form['contact'],
            requester=session['user_id'],
            description=request.form['description'],
            zip_code=user.zip_code
        )
        return redirect(url_for('requests_page'))

    requests_data = Needs.select().join(Users).where(Users.id == Needs.requester)
    return render_template('requests.html', requests=requests_data)

# --- RESOURCES PAGE ---
@app.route('/resources', methods= ['GET','POST'])
def resources():
    if request.method == 'POST':
        user = Users.select().where(Users.id ==(session['user_id'])).get()  
        Resources.create(
            type=request.form['type'],
            city=request.form['city'],
            contact=request.form['contact'],
            provider_id=session['user_id'],
            description=request.form['description'],
            zip_code=request.form['zip'],
            state=request.form['state']
        )
    resources_data = Resources.select()
    return render_template('resources.html', resources=resources_data)

# --- LOGIN PAGE ---
@app.route('/login', methods = ['GET','POST'])
def login():
    if request.method == 'POST':
        user = Users.select().where(Users.username == request.form['username']).get()

        if bcrypt.checkpw(bytes(request.form['password'],encoding='utf8'), bytes(user.password, encoding='utf8')):
                session['user_id'] = user.id
                session['loggedin'] = True
                return redirect(url_for('profile'))
    return render_template('login.html')

@app.route('/register', methods = ['POST','GET'])
def register():
    if request.method == 'POST':
        new_user = Users.create(
            first_name=request.form['first_name'],
            last_name=request.form['last_name'],
            street_address=request.form['street'],
            city=request.form['city'],
            state=request.form['state'],
            zip_code=request.form['zip'],
            username=request.form['username'],
            password=bcrypt.hashpw(bytes(request.form['password'], encoding='utf8'),bcrypt.gensalt(12))
        )
        session['user_id'] = new_user.id
        session['loggedin'] = True
        return redirect(url_for('profile'))
    return render_template('register.html')
# --- RUN APP ---
if __name__ == '__main__':
    app.run(debug=True)
