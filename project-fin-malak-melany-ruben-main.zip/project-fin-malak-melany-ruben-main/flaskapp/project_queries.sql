-- === Create Tables ===

-- Users table
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    first_name VARCHAR NOT NULL,
    last_name VARCHAR NOT NULL,
    street_address VARCHAR,
    city VARCHAR,
    state VARCHAR,
    zip_code VARCHAR,
    volunteer BOOLEAN,
    admin BOOLEAN
);

-- Needs table
CREATE TABLE needs (
    id SERIAL PRIMARY KEY,
    type VARCHAR NOT NULL,
    priority INTEGER NOT NULL,
    contact VARCHAR NOT NULL,
    zip_code VARCHAR NOT NULL,
    requester_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (requester_id) REFERENCES users(id)
);

-- Resources table
CREATE TABLE resources (
    id SERIAL PRIMARY KEY,
    description VARCHAR NOT NULL,
    provider_id INTEGER NOT NULL,
    type VARCHAR NOT NULL,
    street_address VARCHAR NOT NULL,
    city VARCHAR NOT NULL,
    state VARCHAR NOT NULL,
    zip_code VARCHAR NOT NULL,
    FOREIGN KEY (provider_id) REFERENCES users(id)
);

-- Services table
CREATE TABLE services (
    id SERIAL PRIMARY KEY,
    type VARCHAR NOT NULL,
    availability INTEGER NOT NULL,
    provider_id INTEGER NOT NULL,
    FOREIGN KEY (provider_id) REFERENCES users(id)
);

-- === Optional: Trigger to auto-update created_at ===
CREATE OR REPLACE FUNCTION set_created_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.created_at := CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_set_created_at
BEFORE INSERT ON needs
FOR EACH ROW
EXECUTE FUNCTION set_created_at();

-- === Sample Queries ===

-- Match needs with available resources
SELECT
    needs.id AS need_id,
    needs.type,
    requester.first_name || ' ' || requester.last_name AS requester_name,
    resources.id AS resource_id,
    resources.description,
    provider.first_name || ' ' || provider.last_name AS provider_name
FROM needs
JOIN resources ON needs.type = resources.type
JOIN users AS requester ON needs.requester_id = requester.id
JOIN users AS provider ON resources.provider_id = provider.id;

-- Match needs with services
SELECT
    needs.id AS need_id,
    needs.type,
    requester.first_name || ' ' || requester.last_name AS requester_name,
    services.id AS service_id,
    services.availability,
    provider.first_name || ' ' || provider.last_name AS provider_name
FROM needs
JOIN services ON needs.type = services.type
JOIN users AS requester ON needs.requester_id = requester.id
JOIN users AS provider ON services.provider_id = provider.id;

-- View all needs submitted by user ID 7
SELECT * FROM needs WHERE requester_id = 7;

-- Update a specific need
UPDATE needs
SET type = 'Food', priority = 1
WHERE id = 12 AND requester_id = 7;

-- Update profile info
UPDATE users
SET first_name = 'Melany',
    last_name = 'Casanova',
    street_address = '101 Chestnut St',
    city = 'Berea',
    state = 'KY',
    zip_code = '40404',
    volunteer = TRUE
WHERE id = 5;

-- Insert new need
INSERT INTO needs (type, priority, contact, zip_code, requester_id)
VALUES ('Housing', 2, 'contact@email.com', '40508', 7);

-- Add new resource
INSERT INTO resources (
    description, provider_id, type, street_address, city, state, zip_code
) VALUES (
    'Non-perishable food items', 12, 'Food',
    '456 Donation Dr', 'Lexington', 'KY', '40508'
);

-- Search resources and services
SELECT * FROM resources WHERE type ILIKE '%clothing%' OR description ILIKE '%clothing%';
SELECT * FROM services WHERE type ILIKE '%transportation%';

-- Add new service
INSERT INTO services (type, availability, provider_id)
VALUES ('Legal Aid', 3, 15);
