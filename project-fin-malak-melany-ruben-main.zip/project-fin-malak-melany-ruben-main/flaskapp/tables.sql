-- https://www.postgresqltutorial.com/

CREATE TABLE "users" (
    "id" SERIAL PRIMARY KEY NOT NULL,
    "first_name" VARCHAR(20) NOT NULL,
    "last_name" VARCHAR(20) NOT NULL,
    "street_address" VARCHAR(100),
    "city" VARCHAR(20),
    "state" VARCHAR(2) NOT NULL,
    "zip_code" VARCHAR(10) NOT NULL,
    "username" VARCHAR(30) NOT NULL,
    "password" VARCHAR(90) 
    
);

CREATE TABLE "needs" (
    "id" SERIAL PRIMARY KEY NOT NULL,
    "type" VARCHAR(20) NOT NULL,
    "priority" VARCHAR(6) NOT NULL,
    "requester_id" INTEGER NOT NULL,
    "contact" VARCHAR(30),
    "description" VARCHAR(300),
    FOREIGN KEY ("requester_id") REFERENCES "users"("id")
    ON DELETE CASCADE
);

CREATE TABLE "resources" (
    "id" SERIAL PRIMARY KEY NOT NULL,
    "description" VARCHAR(250) NOT NULL,
    "provider_id" INTEGER NOT NULL,
    "type" VARCHAR(20) NOT NULL,
    "street_address" VARCHAR(200),
    "city" VARCHAR(20) NOT NULL,
    "state" VARCHAR(2) NOT NULL,
    "zip_code" VARCHAR(10) NOT NULL,
    FOREIGN KEY ("provider_id") REFERENCES "users"("id")
    ON DELETE CASCADE
);

CREATE TABLE "services" (
    "id" SERIAL PRIMARY KEY NOT NULL,
    "type" VARCHAR(20) NOT NULL,
    "availability" INTEGER NOT NULL,
    "provider_id" INTEGER NOT NULL,
    FOREIGN KEY ("provider_id") REFERENCES "users"("id")
    ON DELETE CASCADE
);

