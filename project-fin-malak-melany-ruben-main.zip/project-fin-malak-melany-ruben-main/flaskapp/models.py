from peewee import PostgresqlDatabase, Model, CharField, IntegerField, BooleanField, ForeignKeyField, fn

# Database Configuration
db = PostgresqlDatabase(
    'ksec',
    user='postgres',
    password='',
    host='localhost',
    port=5432
)

# Base Model
class BaseModel(Model):
    class Meta:
        database = db

# Users Table
class Users(BaseModel):
    id = IntegerField(primary_key=True)
    first_name = CharField()
    last_name = CharField()
    street_address = CharField(null=True)
    city = CharField(null=True)
    state = CharField(null=True)
    zip_code = CharField(null=True)
    username = CharField()
    password = CharField()

# Needs Table
class Needs(BaseModel):
    id = IntegerField()
    type = CharField()
    priority = IntegerField()
    contact = CharField()
    requester = ForeignKeyField(Users, backref='Needs')
    description=CharField()

# Resources Table
class Resources(BaseModel):
    id = IntegerField()
    description = CharField()
    provider = ForeignKeyField(Users, backref='Resources')
    type = CharField()
    street_address = CharField()
    city = CharField()
    state = CharField()
    zip_code = CharField()

# Services Table
class Services(BaseModel):
    type = CharField()
    availability = IntegerField()
    provider = ForeignKeyField(Users, backref='Services')
