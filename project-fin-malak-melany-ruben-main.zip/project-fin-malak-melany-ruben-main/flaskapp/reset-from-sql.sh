# Remove objects from the database
psql -c "DROP DATABASE IF EXISTS ksec;"
psql -c "CREATE DATABASE ksec;"
psql -d ksec -c "DROP table IF EXISTS services;"
psql -d ksec -c "DROP table IF EXISTS needs;"
psql -d ksec -c "DROP table IF EXISTS resources;"
psql -d ksec -c "DROP table IF EXISTS users;"
psql -c "DROP role IF EXISTS admin;"
psql -c "DROP role IF EXISTS general;"
psql -d ksec -c "CREATE USER admin;"
psql -d ksec -c "CREATE USER general;"

# Create tables
< tables.sql psql -d ksec
psql -d ksec -c "GRANT SELECT, UPDATE, DELETE ON services,resources,needs,users to admin;"
psql -d ksec -c "GRANT SELECT, UPDATE, DELETE ON services,resources,needs to general;"
psql -d ksec -c "GRANT SELECT ON users to general;"
# Load data back into database
< data.sql psql -d ksec
